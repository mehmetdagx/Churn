import pandas as pd
import xgboost as xgb
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib
import os

# Define paths
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_FILE = os.path.join(BASE_DIR, "WA_Fn-UseC_-Telco-Customer-Churn.csv")
MODEL_DIR = os.path.join(BASE_DIR, "model_artifacts")
MODEL_PATH = os.path.join(MODEL_DIR, "xgboost_churn_model.joblib")
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.joblib")
COLUMNS_PATH = os.path.join(MODEL_DIR, "model_columns.json")
TOTAL_CHARGES_MEAN_PATH = os.path.join(MODEL_DIR, "total_charges_mean.json")
NUMERICAL_COLS_PATH = os.path.join(MODEL_DIR, "numerical_cols.json")

# Create directory for model artifacts if it doesn't exist
os.makedirs(MODEL_DIR, exist_ok=True)

# Load the dataset
df = pd.read_csv(DATA_FILE)

# --- Preprocessing --- 
# Handle TotalCharges: Convert to numeric, coercing errors, then fill NaNs with the mean
df["TotalCharges"] = pd.to_numeric(df["TotalCharges"], errors="coerce")
total_charges_mean = df["TotalCharges"].mean()
df["TotalCharges"].fillna(total_charges_mean, inplace=True)
joblib.dump({"total_charges_mean": total_charges_mean}, TOTAL_CHARGES_MEAN_PATH)

# Identify categorical columns for one-hot encoding (excluding customerID for now, will be dropped)
original_categorical_cols = df.select_dtypes(include="object").columns.tolist()
if "customerID" in original_categorical_cols:
    original_categorical_cols.remove("customerID")

# Store original df before get_dummies for the app to use for customer lookup
# df_original_for_app = df.copy()

# One-hot encode categorical features
df = pd.get_dummies(df, columns=original_categorical_cols, drop_first=True)

# Define target and features
TARGET_COL = None
if "Churn_Yes" in df.columns:
    TARGET_COL = "Churn_Yes"
elif "Churn" in df.columns and df["Churn"].dtype != 'object': # If Churn was already binary
    TARGET_COL = "Churn"
else:
    # This case should ideally not happen if notebook logic is followed
    # but as a fallback, find a column containing 'Churn' that is boolean or integer
    possible_target_cols = [col for col in df.columns if "Churn" in col and (df[col].dtype == 'bool' or df[col].dtype == 'int')]
    if possible_target_cols:
        TARGET_COL = possible_target_cols[0]
    else:
        raise ValueError("Could not identify the binary target column for Churn after dummification.")

X = df.drop(columns=[TARGET_COL, "customerID"])
y = df[TARGET_COL]

# Save the column order and names for the Flask app
model_columns = X.columns.tolist()
joblib.dump(model_columns, COLUMNS_PATH)

# Split data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

# Identify numerical columns for scaling (excluding binary/dummy variables)
# These are columns that were originally int64 or float64 and are not purely 0/1 after get_dummies
# Or, more simply, columns that were numeric before dummification and are still present
numerical_cols_to_scale = []
# Original numeric columns (excluding SeniorCitizen if it's considered categorical for scaling, but notebook scales it)
original_numeric_cols = ['tenure', 'MonthlyCharges', 'TotalCharges', 'SeniorCitizen'] 
for col in original_numeric_cols:
    if col in X_train.columns:
        numerical_cols_to_scale.append(col)

# Ensure SeniorCitizen is treated as in the notebook (it was scaled)
if 'SeniorCitizen' not in numerical_cols_to_scale and 'SeniorCitizen' in X_train.columns:
     numerical_cols_to_scale.append('SeniorCitizen')

# Filter out columns that might have become boolean/object after some manipulation if any (should not happen here)
numerical_cols_to_scale = [col for col in numerical_cols_to_scale if X_train[col].dtype in ['int64', 'float64']]

joblib.dump(numerical_cols_to_scale, NUMERICAL_COLS_PATH)

# Scale numerical features
scaler = StandardScaler()
if numerical_cols_to_scale: # Check if there are numerical columns to scale
    X_train[numerical_cols_to_scale] = scaler.fit_transform(X_train[numerical_cols_to_scale])
    X_test[numerical_cols_to_scale] = scaler.transform(X_test[numerical_cols_to_scale])

# Save the scaler
joblib.dump(scaler, SCALER_PATH)

# --- Model Training --- 
# Initialize and train the XGBoost classifier
# Check XGBoost version for use_label_encoder parameter
xgb_major_version = int(xgb.__version__.split('.')[0])
if xgb_major_version < 2:
    model = xgb.XGBClassifier(objective="binary:logistic", eval_metric="logloss", use_label_encoder=False)
else:
    model = xgb.XGBClassifier(objective="binary:logistic", eval_metric="logloss")

model.fit(X_train, y_train)

# Save the trained model
joblib.dump(model, MODEL_PATH)

print(f"Model saved to {MODEL_PATH}")
print(f"Scaler saved to {SCALER_PATH}")
print(f"Model columns saved to {COLUMNS_PATH}")
print(f"TotalCharges mean saved to {TOTAL_CHARGES_MEAN_PATH}")
print(f"Numerical columns for scaling saved to {NUMERICAL_COLS_PATH}")

# (Optional) Evaluate the model to ensure consistency with notebook
from sklearn.metrics import accuracy_score, classification_report
y_pred_test = model.predict(X_test)
print("\nModel Evaluation on Test Set (from prepare_artifacts.py):")
print(f"Accuracy: {accuracy_score(y_test, y_pred_test):.2f}")
print(classification_report(y_test, y_pred_test))

