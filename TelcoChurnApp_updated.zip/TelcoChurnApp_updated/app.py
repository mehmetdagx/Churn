import flask
import pandas as pd
import joblib
import os
import numpy as np

app = flask.Flask(__name__)

# --- Configuration and Paths ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
MODEL_DIR = os.path.join(BASE_DIR, "model_artifacts")
MODEL_PATH = os.path.join(MODEL_DIR, "xgboost_churn_model.joblib")
SCALER_PATH = os.path.join(MODEL_DIR, "scaler.joblib")
MODEL_COLUMNS_PATH = os.path.join(MODEL_DIR, "model_columns.json")
TOTAL_CHARGES_MEAN_PATH = os.path.join(MODEL_DIR, "total_charges_mean.json")
NUMERICAL_COLS_PATH = os.path.join(MODEL_DIR, "numerical_cols.json")
ORIGINAL_DATA_PATH = os.path.join(BASE_DIR, "WA_Fn-UseC_-Telco-Customer-Churn.csv") # This now points to the new dataset

# --- Load Artifacts --- 
try:
    model = joblib.load(MODEL_PATH)
    scaler = joblib.load(SCALER_PATH)
    model_columns = joblib.load(MODEL_COLUMNS_PATH)
    total_charges_mean_data = joblib.load(TOTAL_CHARGES_MEAN_PATH)
    total_charges_mean = total_charges_mean_data["total_charges_mean"]
    numerical_cols_to_scale = joblib.load(NUMERICAL_COLS_PATH)
    original_df = pd.read_csv(ORIGINAL_DATA_PATH)
    # Ensure customerID in original_df is treated as string for comparison with form input, or cast form input to int
    # For simplicity, let's ensure original_df['customerID'] is string if it's read as int, to match form input type
    # However, the user mentioned customer IDs are now numeric. So, we should cast the form input to int.
except Exception as e:
    print(f"Error loading artifacts: {e}")
    model = None

def preprocess_single_customer(customer_raw_data_series, original_df_columns_for_get_dummies):
    if model is None:
        raise Exception("Model artifacts not loaded. Cannot preprocess.")

    customer_df = customer_raw_data_series.to_frame().T
    customer_df["TotalCharges"] = pd.to_numeric(customer_df["TotalCharges"], errors="coerce")
    customer_df["TotalCharges"].fillna(total_charges_mean, inplace=True)

    original_categorical_cols = []
    # temp_original_df = pd.read_csv(ORIGINAL_DATA_PATH) # No need to reload, original_df is already loaded
    for col in original_df.columns:
        if original_df[col].dtype == 'object' and col not in ["customerID", "Churn"]:
            original_categorical_cols.append(col)
    
    processed_df = pd.get_dummies(customer_df, columns=original_categorical_cols, drop_first=False)

    for col in model_columns:
        if col not in processed_df.columns:
            processed_df[col] = 0 
            
    processed_df = processed_df.reindex(columns=model_columns, fill_value=0)

    cols_to_scale_for_this_customer = [col for col in numerical_cols_to_scale if col in processed_df.columns]
    if cols_to_scale_for_this_customer:
        processed_df[cols_to_scale_for_this_customer] = scaler.transform(processed_df[cols_to_scale_for_this_customer])

    return processed_df

@app.route("/", methods=["GET"])
def home():
    return flask.render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    prediction_text = None
    error_text = None
    customer_display_data = None

    if model is None:
        error_text = "Model veya gerekli dosyalar yüklenemedi. Lütfen sunucu kayıtlarını kontrol edin."
        return flask.render_template("index.html", error_text=error_text)

    try:
        customer_id_from_form = flask.request.form["customerID"]
        
        # Since customerID in the new dataset is numeric, convert form input to int for lookup
        try:
            customer_id_lookup = int(customer_id_from_form)
        except ValueError:
            error_text = f"Geçersiz Müşteri ID formatı: 	'{customer_id_from_form}	'. Lütfen sayısal bir ID girin."
            return flask.render_template("index.html", error_text=error_text)

        customer_raw_data = original_df[original_df["customerID"] == customer_id_lookup]

        if customer_raw_data.empty:
            error_text = f"'{customer_id_from_form}' ID'li müşteri bulunamadı."
        else:
            customer_raw_data_series = customer_raw_data.iloc[0].copy()
            customer_display_data = customer_raw_data_series.to_dict()
            # Ensure customerID displayed is the one entered by user (string)
            customer_display_data["customerID_display"] = customer_id_from_form 

            preprocessed_customer_data = preprocess_single_customer(customer_raw_data_series, []) # original_categorical_cols_for_dummify not strictly needed here as it's re-derived in preprocess
            
            prediction = model.predict(preprocessed_customer_data)
            prediction_proba = model.predict_proba(preprocessed_customer_data)

            if prediction[0] == 1:
                prediction_text = f"'{customer_id_from_form}' ID'li müşteri %{prediction_proba[0][1]*100:.2f} olasılıkla hizmeti BIRAKACAK."
            else:
                prediction_text = f"'{customer_id_from_form}' ID'li müşteri %{prediction_proba[0][0]*100:.2f} olasılıkla hizmete DEVAM EDECEK."

    except Exception as e:
        error_text = f"Bir hata oluştu: {str(e)}"
        import traceback
        print(traceback.format_exc())

    return flask.render_template("index.html", 
                                 prediction_text=prediction_text, 
                                 error_text=error_text, 
                                 customer_data=customer_display_data)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)

